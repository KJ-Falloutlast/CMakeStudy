#include <iostream>

int main(int argc, char* argv[])
{
    std::cout << "Hello Main1!" << std::endl;
    return 0;
}