#!/bin/bash

make package
