#include <iostream>

#include "Hello.h"

void Hello::print()
{
    std::cout << "Hello Install!" << std::endl;
}
