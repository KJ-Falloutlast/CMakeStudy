#include <iostream>
#include <fmt/format.h>

int main(int argc, char *argv[])
{
    fmt::print("Hello, {}. This is {}!\n", "conan", "fmtlib");
    return 0;
}
