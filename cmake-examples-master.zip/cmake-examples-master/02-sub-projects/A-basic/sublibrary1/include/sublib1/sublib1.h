#ifndef __SUBLIB_1_H__
#define __SUBLIB_1_H__

class sublib1
{
public:
    void print();
};

#endif
