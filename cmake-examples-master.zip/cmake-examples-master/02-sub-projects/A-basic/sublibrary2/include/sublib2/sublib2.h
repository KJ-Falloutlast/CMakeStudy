#ifndef __SUBLIB_2_H__
#define __SUBLIB_2_H__

#include <iostream>

class sublib2
{
public:
    void print()
    {
        std::cout << "Hello header only sub-library 2!" << std::endl;
    }
};

#endif
