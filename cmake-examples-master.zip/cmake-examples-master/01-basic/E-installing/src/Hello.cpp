#include <iostream>

#include "installing/Hello.h"

void Hello::print()
{
    std::cout << "Hello Install!" << std::endl;
}
