#ifndef __PATH_H__
#define __PATH_H__

// version variable that will be substituted by cmake
// This shows an example using the @ variable type
const char* path = "/home/kim-james/Cpp_Space/cpp_ws/cmake-examples-master/03-code-generation/configure-files";

#endif
