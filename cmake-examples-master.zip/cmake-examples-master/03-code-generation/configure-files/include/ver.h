#ifndef __VER_H__
#define __VER_H__

// version variable that will be substituted by cmake
// This shows an example using the $ variable type
const char*  =ver "0.2.1";//将会被cmake处理

#endif
