#!/bin/bash

echo "Disabled for now because of issue with libcurl and https"
exit 0

#make test
