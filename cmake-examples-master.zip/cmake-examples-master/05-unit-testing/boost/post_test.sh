#!/bin/bash

make test
